-- VIDA OS™ — Planning Content PC-M01 executable candidate v0.1
-- STATUS: CANDIDATE / NON-DEPLOYED / DO NOT APPLY WITHOUT GATE APPROVAL
-- SOURCE: planning-content-full-commented-ddl-candidate-v0.4.sql

-- PC-M01 — ACTOR / AUTHORSHIP INFRASTRUCTURE
-- ============================================================================

CREATE TABLE public.planning_content_actor_stamps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  actor_auth_user_id uuid NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  actor_label_snapshot text NOT NULL CHECK (btrim(actor_label_snapshot) <> ''),
  actor_origin text NOT NULL
    CHECK (actor_origin IN ('planner','client','system','external')),
  recorded_at timestamptz NOT NULL,
  CONSTRAINT pc_actor_stamp_eng_fk
    FOREIGN KEY (client_account_id, planning_engagement_id)
    REFERENCES public.planning_engagements(client_account_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_actor_stamp_ctx_uq
    UNIQUE (client_account_id, planning_engagement_id, id),
  CONSTRAINT pc_actor_stamp_human_ck
    CHECK (
      actor_origin IN ('system','external')
      OR actor_auth_user_id IS NOT NULL
    )
);
ALTER TABLE public.planning_content_actor_stamps ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_actor_stamps
  FROM PUBLIC, anon, authenticated, service_role;

CREATE TABLE public.planning_content_actor_stamp_authorizations (
  actor_stamp_id uuid NOT NULL,
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  authorization_id uuid NOT NULL
    REFERENCES public.client_account_user_authorizations(id)
    ON DELETE RESTRICT,
  PRIMARY KEY (actor_stamp_id, authorization_id),
  CONSTRAINT pc_actor_auth_stamp_fk
    FOREIGN KEY (client_account_id, planning_engagement_id, actor_stamp_id)
    REFERENCES public.planning_content_actor_stamps(client_account_id, planning_engagement_id, id)
    ON DELETE RESTRICT
);
ALTER TABLE public.planning_content_actor_stamp_authorizations ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_actor_stamp_authorizations
  FROM PUBLIC, anon, authenticated, service_role;

-- Canonical writer must prove each authorization:
--   * belongs to the same client_account;
--   * belonged to actor_auth_user_id when the act occurred;
--   * was active at act time;
--   * was backed by current membership at act time;
--   * satisfied every required scope for that command.
-- This cross-table authorization-set rule is procedural; it is not reducible
-- to one FK because client-side acts may require BOTH engagement + entity grants.

-- ============================================================================
