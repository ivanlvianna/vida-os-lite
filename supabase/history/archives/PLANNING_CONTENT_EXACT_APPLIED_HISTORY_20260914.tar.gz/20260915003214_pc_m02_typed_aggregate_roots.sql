-- VIDA OS™ — Planning Content PC-M02 executable candidate v0.1
-- STATUS: CANDIDATE / NON-DEPLOYED / DO NOT APPLY WITHOUT GATE APPROVAL
-- SOURCE: planning-content-full-commented-ddl-candidate-v0.4.sql

-- PC-M02 — TYPED AGGREGATE ROOTS
-- ============================================================================

CREATE TABLE public.planning_content_interview_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  created_actor_stamp_id uuid NOT NULL,
  created_at timestamptz NOT NULL
,
  CONSTRAINT pc_deb20c7_eng_fk
    FOREIGN KEY (client_account_id, planning_engagement_id)
    REFERENCES public.planning_engagements(client_account_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_deb20c7_actor_fk
    FOREIGN KEY (client_account_id, planning_engagement_id, created_actor_stamp_id)
    REFERENCES public.planning_content_actor_stamps(client_account_id, planning_engagement_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_deb20c7_ctx_uq
    UNIQUE (client_account_id, planning_engagement_id, id)

);
ALTER TABLE public.planning_content_interview_records ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_interview_records FROM PUBLIC, anon, authenticated, service_role;


CREATE TABLE public.planning_content_instrument_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  created_actor_stamp_id uuid NOT NULL,
  created_at timestamptz NOT NULL
,
  instrument_code text NOT NULL
    CHECK (instrument_code IN ('ICV-01','IMDP-01','IVRP-01')),
  CONSTRAINT pc_73a961c_eng_fk
    FOREIGN KEY (client_account_id, planning_engagement_id)
    REFERENCES public.planning_engagements(client_account_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_73a961c_actor_fk
    FOREIGN KEY (client_account_id, planning_engagement_id, created_actor_stamp_id)
    REFERENCES public.planning_content_actor_stamps(client_account_id, planning_engagement_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_73a961c_ctx_uq
    UNIQUE (client_account_id, planning_engagement_id, id)
,
  CONSTRAINT pc_instr_run_code_uq
    UNIQUE (client_account_id, planning_engagement_id, id, instrument_code)
);
ALTER TABLE public.planning_content_instrument_runs ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_instrument_runs FROM PUBLIC, anon, authenticated, service_role;


CREATE TABLE public.planning_content_diagnostic_syntheses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  created_actor_stamp_id uuid NOT NULL,
  created_at timestamptz NOT NULL
,
  CONSTRAINT pc_0fdf08a_eng_fk
    FOREIGN KEY (client_account_id, planning_engagement_id)
    REFERENCES public.planning_engagements(client_account_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_0fdf08a_actor_fk
    FOREIGN KEY (client_account_id, planning_engagement_id, created_actor_stamp_id)
    REFERENCES public.planning_content_actor_stamps(client_account_id, planning_engagement_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_0fdf08a_ctx_uq
    UNIQUE (client_account_id, planning_engagement_id, id)

);
ALTER TABLE public.planning_content_diagnostic_syntheses ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_diagnostic_syntheses FROM PUBLIC, anon, authenticated, service_role;


CREATE TABLE public.planning_content_working_hypotheses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  created_actor_stamp_id uuid NOT NULL,
  created_at timestamptz NOT NULL
,
  origin_diagnostic_synthesis_version_id uuid NOT NULL,
  origin_proposal_key uuid NOT NULL,
  CONSTRAINT pc_0afdd6d_eng_fk
    FOREIGN KEY (client_account_id, planning_engagement_id)
    REFERENCES public.planning_engagements(client_account_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_0afdd6d_actor_fk
    FOREIGN KEY (client_account_id, planning_engagement_id, created_actor_stamp_id)
    REFERENCES public.planning_content_actor_stamps(client_account_id, planning_engagement_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_0afdd6d_ctx_uq
    UNIQUE (client_account_id, planning_engagement_id, id)

);
ALTER TABLE public.planning_content_working_hypotheses ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_working_hypotheses FROM PUBLIC, anon, authenticated, service_role;


CREATE TABLE public.planning_content_hypothesis_agendas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  created_actor_stamp_id uuid NOT NULL,
  created_at timestamptz NOT NULL
,
  CONSTRAINT pc_5e57b0f_eng_fk
    FOREIGN KEY (client_account_id, planning_engagement_id)
    REFERENCES public.planning_engagements(client_account_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_5e57b0f_actor_fk
    FOREIGN KEY (client_account_id, planning_engagement_id, created_actor_stamp_id)
    REFERENCES public.planning_content_actor_stamps(client_account_id, planning_engagement_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_5e57b0f_ctx_uq
    UNIQUE (client_account_id, planning_engagement_id, id)

);
ALTER TABLE public.planning_content_hypothesis_agendas ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_hypothesis_agendas FROM PUBLIC, anon, authenticated, service_role;


CREATE TABLE public.planning_content_diagnostic_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  created_actor_stamp_id uuid NOT NULL,
  created_at timestamptz NOT NULL
,
  CONSTRAINT pc_27209a4_eng_fk
    FOREIGN KEY (client_account_id, planning_engagement_id)
    REFERENCES public.planning_engagements(client_account_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_27209a4_actor_fk
    FOREIGN KEY (client_account_id, planning_engagement_id, created_actor_stamp_id)
    REFERENCES public.planning_content_actor_stamps(client_account_id, planning_engagement_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_27209a4_ctx_uq
    UNIQUE (client_account_id, planning_engagement_id, id)

);
ALTER TABLE public.planning_content_diagnostic_sessions ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_diagnostic_sessions FROM PUBLIC, anon, authenticated, service_role;


CREATE TABLE public.planning_content_diagnostic_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  created_actor_stamp_id uuid NOT NULL,
  created_at timestamptz NOT NULL
,
  CONSTRAINT pc_5ba1a6e_eng_fk
    FOREIGN KEY (client_account_id, planning_engagement_id)
    REFERENCES public.planning_engagements(client_account_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_5ba1a6e_actor_fk
    FOREIGN KEY (client_account_id, planning_engagement_id, created_actor_stamp_id)
    REFERENCES public.planning_content_actor_stamps(client_account_id, planning_engagement_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_5ba1a6e_ctx_uq
    UNIQUE (client_account_id, planning_engagement_id, id)

);
ALTER TABLE public.planning_content_diagnostic_reports ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_diagnostic_reports FROM PUBLIC, anon, authenticated, service_role;


CREATE TABLE public.planning_content_financial_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  created_actor_stamp_id uuid NOT NULL,
  created_at timestamptz NOT NULL
,
  CONSTRAINT pc_cdd406c_eng_fk
    FOREIGN KEY (client_account_id, planning_engagement_id)
    REFERENCES public.planning_engagements(client_account_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_cdd406c_actor_fk
    FOREIGN KEY (client_account_id, planning_engagement_id, created_actor_stamp_id)
    REFERENCES public.planning_content_actor_stamps(client_account_id, planning_engagement_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_cdd406c_ctx_uq
    UNIQUE (client_account_id, planning_engagement_id, id)

);
ALTER TABLE public.planning_content_financial_plans ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_financial_plans FROM PUBLIC, anon, authenticated, service_role;


CREATE TABLE public.planning_content_implementation_episodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  created_actor_stamp_id uuid NOT NULL,
  created_at timestamptz NOT NULL
,
  CONSTRAINT pc_c6cd084_eng_fk
    FOREIGN KEY (client_account_id, planning_engagement_id)
    REFERENCES public.planning_engagements(client_account_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_c6cd084_actor_fk
    FOREIGN KEY (client_account_id, planning_engagement_id, created_actor_stamp_id)
    REFERENCES public.planning_content_actor_stamps(client_account_id, planning_engagement_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_c6cd084_ctx_uq
    UNIQUE (client_account_id, planning_engagement_id, id)

);
ALTER TABLE public.planning_content_implementation_episodes ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_implementation_episodes FROM PUBLIC, anon, authenticated, service_role;


CREATE TABLE public.planning_content_review_episodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_account_id uuid NOT NULL,
  planning_engagement_id uuid NOT NULL,
  created_actor_stamp_id uuid NOT NULL,
  created_at timestamptz NOT NULL
,
  CONSTRAINT pc_4660f18_eng_fk
    FOREIGN KEY (client_account_id, planning_engagement_id)
    REFERENCES public.planning_engagements(client_account_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_4660f18_actor_fk
    FOREIGN KEY (client_account_id, planning_engagement_id, created_actor_stamp_id)
    REFERENCES public.planning_content_actor_stamps(client_account_id, planning_engagement_id, id)
    ON DELETE RESTRICT,
  CONSTRAINT pc_4660f18_ctx_uq
    UNIQUE (client_account_id, planning_engagement_id, id)

);
ALTER TABLE public.planning_content_review_episodes ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.planning_content_review_episodes FROM PUBLIC, anon, authenticated, service_role;

-- ============================================================================
